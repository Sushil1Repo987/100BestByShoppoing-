package com.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.shopping.pojo.Affiliate;
import com.shopping.pojo.Customer;
import com.shopping.pojo.Employee;
import com.shopping.pojo.Product;
import com.shopping.service.UserType;

public class Factoty {
	static Affiliate aff;

	public static double userDiscount(String UserName, double amount, String productName) throws ParseException {
		Affiliate aff = new Affiliate();
		aff.setName("sushil");
		String strdate1 = "02-04-2019 11:35:42";
		aff.setResisterDate(strdate1);
		Product pro = new Product();
		pro.setProductName("Electronics");
		aff.setProduct(pro);

		Customer cus = new Customer();
		cus.setName("Rohit");
		String strdate2 = "02-04-2019 11:35:42";
		cus.setResisterDate(strdate2);

		Employee emp = new Employee();
		emp.setName("Mohit");
		String strdate3 = "02-04-2019 11:35:42";
		emp.setResisterDate(strdate2);

		double paymentAfterDiscount = 0;

		if (UserName.equalsIgnoreCase(aff.getName())) {

			paymentAfterDiscount = aff.getUserType(amount, productName);

		} else if (UserName.equals(cus.getName())) {
			paymentAfterDiscount = cus.getUserType(amount, productName);

		} else if (UserName.equals(emp.getName())) {
			Date today = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
			Date d1 = sdf.parse(today.toString());
			Date d2 = sdf.parse(emp.getResisterDate());
			long difference_In_Time = d2.getTime() - d1.getTime();
			long difference_In_Years = (difference_In_Time / (1000l * 60 * 60 * 24 * 365));
			if (difference_In_Years > 2) {
				paymentAfterDiscount = cus.getUserType(amount, productName);
			}

		} else {

			double quotient = amount / 100;

			paymentAfterDiscount = amount - (quotient * 5);

		}

		return paymentAfterDiscount;
	}

}
