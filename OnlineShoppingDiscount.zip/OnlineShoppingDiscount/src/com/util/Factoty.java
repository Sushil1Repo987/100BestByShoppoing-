package com.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.shopping.pojo.Affiliate;
import com.shopping.pojo.Customer;
import com.shopping.pojo.Employee;
import com.shopping.pojo.Product;
import com.shopping.service.UserType;

public class Factoty {
	static Affiliate aff;

	public static double userDiscount(String UserName, double amount, String productName) throws ParseException {
		Affiliate aff = new Affiliate();
		aff.setName("sushil");
		String strdate1 = "02-04-2019 11:35:42";
		aff.setResisterDate(strdate1);
		

		Customer cus = new Customer();
		cus.setName("Rohit");
		String strdate2 = "02-04-2019 11:35:42";
		cus.setResisterDate(strdate2);

		Employee emp = new Employee();
		emp.setName("Mohit");
		String strdate3 = "02-04-2019 11:35:42";
		emp.setResisterDate(strdate3);

		double paymentAfterDiscount = 0;

		if (UserName.equalsIgnoreCase(aff.getName())) {

			paymentAfterDiscount = aff.getUserType(amount, productName);

		} else if (UserName.equals(cus.getName())) {
			paymentAfterDiscount = cus.getUserType(amount, productName);

		} else if (UserName.equals(emp.getName())){
			
			SimpleDateFormat obj = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
			Date date1 = obj.parse("12-12-2018 02:11:20");
			Date date2 = obj.parse("1-26-2020 07:15:50");
			long time_difference = date2.getTime() - date1.getTime();
			long hours_difference = (time_difference / (1000 * 60 * 60)) % 24;
			if (hours_difference > 2) {
				paymentAfterDiscount = cus.getUserType(amount, productName);
			}

		} else {

			double quotient = amount / 100;

			paymentAfterDiscount = amount - (quotient * 5);

		}

		return paymentAfterDiscount;
	}

}
