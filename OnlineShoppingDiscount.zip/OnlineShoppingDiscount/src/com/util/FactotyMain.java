package com.util;

import java.text.ParseException;

import com.shopping.pojo.Affiliate;
import com.shopping.pojo.Customer;
import com.shopping.pojo.Employee;
import com.shopping.pojo.Product;

public class FactotyMain {

	public static void main(String[] args) {
		
		

		try {
			//System.out.println(Factoty.userDiscount("Sushil", 500, "Electronics"));
			System.out.println(Factoty.userDiscount("Mohit", 500, "Electronics"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
