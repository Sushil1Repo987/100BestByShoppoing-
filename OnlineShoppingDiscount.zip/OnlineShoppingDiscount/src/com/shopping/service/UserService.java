package com.shopping.service;

import java.util.List;

import com.shopping.pojo.User;

public interface UserService {
	public List<User> discount(User user);
		
}
