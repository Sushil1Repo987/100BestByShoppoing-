package com.shopping.service;

import java.util.List;

import com.shopping.pojo.Product;
import com.shopping.pojo.User;

public interface UserType {
	double getUserType(double amount,String productName);
	
	
	

}
