package com.shopping.pojo;

public class Product {
	String ProductName;

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

}
