package com.shopping.pojo;

import java.util.Date;

import com.shopping.service.UserType;

public class Employee implements UserType{

private String name ;
private Integer id;
private String resisterDate;


public String getResisterDate() {
	return resisterDate;
}
public void setResisterDate(String strdate2) {
	this.resisterDate = strdate2;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Override
public String toString() {
	return "Affiliate [name=" + name + ", id=" + id + "]";
}
@Override
public double getUserType(double amount,String productName) {
	
	double pay=amount;
	if(!productName.equals("groceries")){
	
	 double quotient = amount /30;
		pay = amount - quotient;
		return pay;
	}
	
	return pay;
}


}
