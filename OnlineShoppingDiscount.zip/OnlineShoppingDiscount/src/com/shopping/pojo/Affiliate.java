package com.shopping.pojo;

import java.util.Date;

import com.shopping.service.UserType;

public class Affiliate implements UserType {

private String name ;
private Integer id;
private String resisterDate;
private Product product;

public String getResisterDate() {
	return resisterDate;
}
public void setResisterDate(String strdate2) {
	this.resisterDate = strdate2;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Override
public String toString() {
	return "Affiliate [name=" + name + ", id=" + id + "]";
}


public Product getProduct() {
	return product;
}
public void setProduct(Product product) {
	this.product = product;
}
@Override
public double getUserType(double amount,String productName) {
	double pay=amount;
if(!productName.equals("groceries")){
	double quotient = amount /10;
	pay = amount - quotient;
	return pay;
}
return pay;
}


}
